#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// gcc checkpoint.c -o checkpoint
unsigned int size = 0x20;
char strength[0x10] = "WEAKDULL";

__attribute__((constructor)) void init_stuff() {
	setbuf(stdin, NULL);
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	return;
}

void main() {

	char name[0x100] = {0};
	char vuln_buffer[0x50] = {0};

	while (1) {
		
		puts("Double edged: ");
		fgets(name, 0xff, stdin);
		printf(name);

		puts("Want to keep brandishing it? ");
		fgets(name, 10, stdin);

		if (!strncmp(name, "n", 1)) {
			break;
		}
		memset(name, 0, 50);
	}
	
	if (strncmp(strength, "STRENGTH", 8)) {
		puts("Unfortunately, your blade is not strong enough.");
		exit(0);
	}

	puts("\nYour blade is strong! Now, to test if your blade can kill: ");
	fgets(vuln_buffer, size, stdin);
}

// challenge description:
// pass the bladesmith's test.
